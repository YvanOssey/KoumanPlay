import { createPortal } from "react-dom";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import {
  ArrowLeft,
  ArrowRight,
  Bell,
  BookOpen,
  Check,
  ChevronRight,
  CircleUserRound,
  Flame,
  Gamepad2,
  HeartHandshake,
  Home as HomeIcon,
  LockKeyhole,
  Menu,
  Music2,
  Play,
  Plus,
  Sparkles,
  Trophy,
  Utensils,
  UsersRound,
  X,
  Zap,
} from "lucide-react";

type Screen = "splash" | "onboarding-play" | "onboarding-learn" | "onboarding-share" | "profile-choice" | "home" | "play" | "knowledge" | "senior-home" | "senior-knowledge" | "senior-challenges" | "senior-profile" | "challenges" | "profile" | "account-settings" | "quiz" | "results" | "challenge-detail";

type NavItem = {
  id: Screen;
  label: string;
  icon: typeof HomeIcon;
};

const navItems: NavItem[] = [
  { id: "home", label: "Accueil", icon: HomeIcon },
  { id: "play", label: "Jouer", icon: Gamepad2 },
  { id: "challenges", label: "Défis", icon: HeartHandshake },
  { id: "profile", label: "Profil", icon: CircleUserRound },
];

const DAILY_REWARDS = [20, 30, 40, 50, 60, 80, 150];
const DAILY_BONUS_KEY = "koumanplay:daily-bonus";
const GAME_PROGRESS_KEY = "koumanplay:game-progress";
const BADGE_PROGRESS_KEY = "koumanplay:badge-progress";
const MAX_ENERGY = 5;
const ENERGY_RECOVERY_MS = 10 * 60 * 1000;
const REGULARITY_STREAK_REQUIRED = 3;
const SUCCESS_GOAL_REQUIRED = 10;
const SUCCESS_GOAL_UNLOCK_AT = Math.ceil(SUCCESS_GOAL_REQUIRED / 2);

type GameProgress = {
  xp: number;
  energy: number;
  energyRecoveryAt: number | null;
};

const DEFAULT_GAME_PROGRESS: GameProgress = { xp: 800, energy: 4, energyRecoveryAt: null };

function saveGameProgress(progress: GameProgress) {
  try {
    localStorage.setItem(GAME_PROGRESS_KEY, JSON.stringify(progress));
  } catch {
    // La session reste utilisable même si le stockage local est indisponible.
  }
}

function getGameProgress(): GameProgress {
  try {
    const raw = localStorage.getItem(GAME_PROGRESS_KEY);
    const saved = raw ? JSON.parse(raw) as Partial<GameProgress> : {};
    const energy = Math.min(MAX_ENERGY, Math.max(0, saved.energy ?? DEFAULT_GAME_PROGRESS.energy));
    const energyRecoveryAt = saved.energyRecoveryAt ?? null;
    if (energy === 0 && energyRecoveryAt && Date.now() >= energyRecoveryAt) {
      const restored = { xp: saved.xp ?? DEFAULT_GAME_PROGRESS.xp, energy: MAX_ENERGY, energyRecoveryAt: null };
      saveGameProgress(restored);
      return restored;
    }
    return { xp: saved.xp ?? DEFAULT_GAME_PROGRESS.xp, energy, energyRecoveryAt };
  } catch {
    return DEFAULT_GAME_PROGRESS;
  }
}

function formatEnergyCooldown(remainingMs: number) {
  const totalSeconds = Math.max(0, Math.ceil(remainingMs / 1000));
  const minutes = String(Math.floor(totalSeconds / 60)).padStart(2, "0");
  const seconds = String(totalSeconds % 60).padStart(2, "0");
  return `${minutes}:${seconds}`;
}

type BadgeProgress = {
  unlocked: { regularity: boolean; perfectQuiz: boolean; successGoal: boolean };
  currentStreak: number;
  bestStreak: number;
  totalCorrect: number;
};

const DEFAULT_BADGE_PROGRESS: BadgeProgress = {
  unlocked: { regularity: false, perfectQuiz: false, successGoal: false },
  currentStreak: 0,
  bestStreak: 0,
  totalCorrect: 0,
};

function saveBadgeProgress(progress: BadgeProgress) {
  try {
    localStorage.setItem(BADGE_PROGRESS_KEY, JSON.stringify(progress));
  } catch {
    // La session reste utilisable même si le stockage local est indisponible.
  }
}

function getBadgeProgress(): BadgeProgress {
  try {
    const raw = localStorage.getItem(BADGE_PROGRESS_KEY);
    const saved = raw ? JSON.parse(raw) as Partial<BadgeProgress> : {};
    return {
      unlocked: { ...DEFAULT_BADGE_PROGRESS.unlocked, ...(saved.unlocked ?? {}) },
      currentStreak: saved.currentStreak ?? 0,
      bestStreak: saved.bestStreak ?? 0,
      totalCorrect: saved.totalCorrect ?? 0,
    };
  } catch {
    return DEFAULT_BADGE_PROGRESS;
  }
}

type DailyBonusState = {
  day: number;
  lastClaimed: string | null;
  totalXp: number;
  claimedToday: boolean;
  reward: number;
};

function localDateKey(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function calendarGap(from: string, to: string) {
  const [fromYear, fromMonth, fromDay] = from.split("-").map(Number);
  const [toYear, toMonth, toDay] = to.split("-").map(Number);
  const fromDate = Date.UTC(fromYear, fromMonth - 1, fromDay);
  const toDate = Date.UTC(toYear, toMonth - 1, toDay);
  return Math.round((toDate - fromDate) / 86400000);
}

function getDailyBonusState(profileRole: "jeune" | "senior"): DailyBonusState {
  const today = localDateKey();
  try {
    const raw = localStorage.getItem(`${DAILY_BONUS_KEY}:${profileRole}`);
    const saved = raw ? JSON.parse(raw) as { day?: number; lastClaimed?: string | null; totalXp?: number } : {};
    const day = Math.min(7, Math.max(0, saved.day ?? 0));
    const lastClaimed = saved.lastClaimed ?? null;
    const claimedToday = lastClaimed === today;
    return { day, lastClaimed, totalXp: saved.totalXp ?? 0, claimedToday, reward: claimedToday && day > 0 ? DAILY_REWARDS[day - 1] : DAILY_REWARDS[day === 7 ? 0 : day] };
  } catch {
    return { day: 0, lastClaimed: null, totalXp: 0, claimedToday: false, reward: DAILY_REWARDS[0] };
  }
}

function claimDailyBonus(profileRole: "jeune" | "senior"): DailyBonusState {
  const today = localDateKey();
  const current = getDailyBonusState(profileRole);
  if (current.claimedToday) return current;

  const gap = current.lastClaimed ? calendarGap(current.lastClaimed, today) : null;
  const nextDay = gap === 1 ? (current.day >= 7 ? 1 : current.day + 1) : 1;
  const reward = DAILY_REWARDS[nextDay - 1];
  const nextState = { day: nextDay, lastClaimed: today, totalXp: current.totalXp + reward };
  try {
    localStorage.setItem(`${DAILY_BONUS_KEY}:${profileRole}`, JSON.stringify(nextState));
  } catch {
    // La session reste utilisable même si le stockage local est indisponible.
  }
  return { ...nextState, claimedToday: true, reward };
}

const categories = [
  { name: "Proverbes", detail: "3 niveaux", progress: 72, difficulty: "Facile", icon: "☼", tone: "purple", cover: "/proverbes.webp", iconComponent: Sparkles },
  { name: "Contes", detail: "1 niveau", progress: 28, difficulty: "Intermédiaire", icon: "◒", tone: "orange", cover: "/contes.webp", iconComponent: BookOpen },
  { name: "Traditions", detail: "Disponible", progress: 0, difficulty: "Difficile", icon: "✦", tone: "red", cover: "/onboarding2.webp", iconComponent: UsersRound },
  { name: "Musique", detail: "À découvrir", progress: 0, difficulty: "Facile", icon: "♪", tone: "pink", cover: "/onboarding3.webp", iconComponent: Music2 },
  { name: "Gastronomie", detail: "Nouveau", progress: 0, difficulty: "Intermédiaire", icon: "⌁", tone: "green", cover: "/contes.webp", iconComponent: Utensils },
  { name: "Numérique", detail: "2 activités", progress: 54, difficulty: "Difficile", icon: "⌘", tone: "blue", cover: "/proverbes.webp", iconComponent: Gamepad2 },
];

const homeCategories = categories.filter(({ name }) => name === "Proverbes" || name === "Contes");

function BrandMark({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`brand-mark ${compact ? "brand-mark--compact" : ""}`} aria-label="KoumanPlay">
      <img className="brand-mark__symbol brand-mark__image" src="/koumanplay-logo.svg" alt="" aria-hidden="true" />
      <span className="brand-mark__word">Kouman<span>Play</span></span>
    </div>
  );
}

function ProgressBar({ value, className = "" }: { value: number; className?: string }) {
  return (
    <div className={`progress ${className}`} aria-label={`${value}% de progression`}>
      <span style={{ width: `${value}%` }} />
    </div>
  );
}

function StatPill({ icon, label, value, tone }: { icon: React.ReactNode; label: string; value: string; tone: string }) {
  return (
    <div className={`stat-pill stat-pill--${tone}`}>
      <span className="stat-pill__icon">{icon}</span>
      <div>
        <span className="stat-pill__label">{label}</span>
        <strong>{value}</strong>
      </div>
    </div>
  );
}

function HomeScreen({ onNavigate, profileRole, gameProgress, cooldownRemaining }: { onNavigate: (screen: Screen) => void; profileRole: "jeune" | "senior"; gameProgress: GameProgress; cooldownRemaining: number }) {
  const [categoryFilter, setCategoryFilter] = useState("Toutes");
  const [difficultyFilter, setDifficultyFilter] = useState("Tous les niveaux");
  const [dailyBonus, setDailyBonus] = useState(() => getDailyBonusState(profileRole));
  const [bonusOpen, setBonusOpen] = useState(() => !getDailyBonusState(profileRole).claimedToday);
  const filteredCategories = homeCategories.filter((category) => (categoryFilter === "Toutes" || category.name === categoryFilter) && (difficultyFilter === "Tous les niveaux" || category.difficulty === difficultyFilter));

  useEffect(() => {
    const nextBonus = getDailyBonusState(profileRole);
    setDailyBonus(nextBonus);
    setBonusOpen(!nextBonus.claimedToday);
  }, [profileRole]);

  const handleClaimDailyBonus = () => {
    const claimedBonus = claimDailyBonus(profileRole);
    setDailyBonus(claimedBonus);
    setBonusOpen(false);
    toast(`Bonus quotidien récupéré · Jour ${claimedBonus.day} · +${claimedBonus.reward} XP`);
  };

  return (
    <div className="screen screen--home">
      <div className="mobile-topline">
        <div>
          <p className="eyebrow">MERCREDI 20 SEPTEMBRE</p>
          <h1>Bonjour, Awa <span className="wave">✦</span></h1>
        </div>
        <div className="mobile-topline__actions">
          <button className="daily-bonus-trigger" onClick={() => setBonusOpen(true)} aria-label={`Bonus quotidien, jour ${dailyBonus.day || 1}, +${dailyBonus.reward} XP`}><Flame size={13} fill="currentColor" /><span>J{dailyBonus.day || 1}</span><strong>+{dailyBonus.reward}</strong></button>
          <button className="icon-button icon-button--light" onClick={() => toast("Tu n'as aucune nouvelle notification.")} aria-label="Notifications">
            <Bell size={19} strokeWidth={2.1} />
            <span className="notification-dot" />
          </button>
        </div>
      </div>

      <section className="level-card">
        <div className="level-card__top">
          <div>
            <span className="eyebrow eyebrow--light">TA PROGRESSION</span>
            <div className="level-card__level">Niveau <strong>04</strong></div>
          </div>
          <div className="level-card__xp"><Sparkles size={15} fill="currentColor" /> {gameProgress.xp} XP</div>
        </div>
        <div className="level-card__bottom">
          <div className="level-card__progress"><ProgressBar value={Math.min(100, (gameProgress.xp / 1000) * 100)} /><span>{gameProgress.xp} / 1000 XP</span></div>
          <div className="energy"><Zap size={14} fill="currentColor" /> {gameProgress.energy === 0 ? formatEnergyCooldown(cooldownRemaining) : `${gameProgress.energy}/5`}</div>
        </div>
        <div className="level-card__shape level-card__shape--one" />
        <div className="level-card__shape level-card__shape--two" />
      </section>

      <section className="section-block section-block--resume">
        <div className="section-heading">
          <div>
            <p className="eyebrow">LÀ OÙ TU T'ES ARRÊTÉE</p>
            <h2>Continuer à jouer</h2>
          </div>
          <button className="text-button" onClick={() => onNavigate("play")}>Tout voir <ChevronRight size={15} /></button>
        </div>
        <button className="resume-card" onClick={() => onNavigate("quiz")}>
          <span className="resume-card__art"><Sparkles size={24} /></span>
          <span className="resume-card__copy">
            <span className="resume-card__category">PROVERBES · NIVEAU 03</span>
            <strong>Quel proverbe signifie…</strong>
            <span className="resume-card__meta">Activité 6 sur 8 <ProgressBar value={72} /></span>
          </span>
          <span className="resume-card__arrow"><ArrowRight size={18} /></span>
        </button>
      </section>

      <section className="section-block home-explore">
        <div className="section-heading"><div><p className="eyebrow">À EXPLORER</p><h2>Trouver une activité</h2></div><span className="filter-result-count">{filteredCategories.length} thèmes</span></div>
        <div className="filter-row filter-row--categories">{["Toutes", ...homeCategories.map(({ name }) => name)].map((filter) => <button key={filter} className={categoryFilter === filter ? "is-active" : ""} onClick={() => setCategoryFilter(filter)}>{filter}</button>)}</div>
        <div className="filter-row filter-row--difficulty">{["Tous les niveaux", "Facile", "Intermédiaire", "Difficile"].map((filter) => <button key={filter} className={difficultyFilter === filter ? "is-active" : ""} onClick={() => setDifficultyFilter(filter)}>{filter}</button>)}</div>
        <div className="home-category-list">{filteredCategories.length > 0 ? filteredCategories.map(({ name, detail, progress, tone, iconComponent: Icon, icon, cover }) => <button key={name} className={`home-category-row home-category-row--${tone}`} onClick={() => onNavigate(name === "Proverbes" ? "quiz" : "play")}><span className="home-category-row__visual" style={{ backgroundImage: `url(${cover})` }}><span>{icon}</span></span><span className="home-category-row__copy"><strong>{name}</strong><small>{detail}</small></span>{progress > 0 ? <span className="home-category-row__progress"><ProgressBar value={progress} /><em>{progress}%</em></span> : <span className="home-category-row__play"><Icon size={14} /><ArrowRight size={14} /></span>}</button>) : <div className="filter-empty">Aucune activité ne correspond à ces filtres.</div>}</div>
      </section>

      <section className="feature-challenge" onClick={() => onNavigate("challenge-detail")} role="button" tabIndex={0}>
        <div className="feature-challenge__image" style={{ backgroundImage: "linear-gradient(90deg, rgba(255,222,209,.75) 0%, rgba(255,237,218,.22) 58%, rgba(239,232,255,.08) 100%), url('/onboarding1.webp')" }}>
          <div className="mini-scene mini-scene--grandma"><span>●</span></div>
          <div className="mini-scene mini-scene--young"><span>●</span></div>
          <div className="mini-scene__table" />
          <div className="mini-scene__spark">✦</div>
        </div>
        <div className="feature-challenge__body">
          <span className="eyebrow eyebrow--purple">DÉFI À LA UNE</span>
          <h2>Le proverbe de ma famille</h2>
          <p>Un moment à partager avec une personne de ton entourage.</p>
          <div className="feature-challenge__footer"><span><Sparkles size={14} /> +100 XP</span><span>10 min</span><ChevronRight size={17} /></div>
        </div>
      </section>
      {bonusOpen && createPortal(<div className="daily-bonus-modal" role="dialog" aria-modal="true" aria-labelledby="daily-bonus-title">
        <div className="daily-bonus-modal__scrim" onClick={() => dailyBonus.claimedToday && setBonusOpen(false)} />
        <div className="daily-bonus-modal__panel">
          <button className="daily-bonus-modal__close" onClick={() => setBonusOpen(false)} aria-label="Fermer le bonus"><X size={16} /></button>
          <div className="daily-bonus-modal__confetti" aria-hidden="true">✦　✧　✦</div>
          <span className="eyebrow eyebrow--purple">CONNEXION QUOTIDIENNE</span>
          <h2 id="daily-bonus-title">Ton bonus est prêt</h2>
          <p className="daily-bonus-modal__lead">Reviens chaque jour pour faire grandir ta série.</p>
          <div className="daily-bonus-modal__streak"><Flame size={16} fill="currentColor" /><span>Série actuelle</span><strong>Jour {dailyBonus.day || 1} / 7</strong></div>
          <div className="daily-bonus-modal__grid" aria-label={`Récompenses du jour ${dailyBonus.day || 1}`}>
            {DAILY_REWARDS.map((reward, index) => {
              const day = index + 1;
              const isActive = (dailyBonus.day || 1) === day;
              const isCompleted = (dailyBonus.day || 1) > day;
              return <div key={day} className={`daily-bonus-tile ${isActive ? "is-active" : ""} ${isCompleted ? "is-completed" : ""}`}><small>Jour {day}</small><strong>{isCompleted ? "✓" : `+${reward}`}</strong><span>{isCompleted ? "Reçu" : "XP"}</span></div>;
            })}
          </div>
          <button className="primary-button primary-button--full daily-bonus-modal__claim" onClick={dailyBonus.claimedToday ? () => setBonusOpen(false) : handleClaimDailyBonus}>{dailyBonus.claimedToday ? "Fermer" : "Récupérer"} <ArrowRight size={17} /></button>
          <span className="daily-bonus-modal__note">Une journée manquée remet la série au jour 1.</span>
        </div>
      </div>, document.body)}
    </div>
  );
}

function PlayScreen({ onNavigate }: { onNavigate: (screen: Screen) => void }) {
  return (
    <div className="screen">
      <div className="screen-header">
        <div><p className="eyebrow">TON TERRAIN DE JEU</p><h1>Jouer</h1></div>
        <button className="icon-button" onClick={() => toast("Les catégories sont déjà filtrées pour toi.")}><Menu size={20} /></button>
      </div>
      <div className="screen-intro"><p>Explore les histoires, les sons et les savoirs qui font vivre notre culture.</p></div>
      <div className="category-grid">
        {categories.map(({ name, detail, progress, tone, iconComponent: Icon, icon }) => (
          <button key={name} className={`category-card category-card--${tone}`} onClick={() => onNavigate(name === "Proverbes" ? "quiz" : "play")}>
            <span className="category-card__top"><span className="category-card__symbol">{icon}</span><Icon size={18} /></span>
            <span className="category-card__name">{name}</span>
            <span className="category-card__detail">{detail}</span>
            {progress > 0 ? <ProgressBar value={progress} /> : <span className="category-card__open">Commencer <ArrowRight size={14} /></span>}
          </button>
        ))}
      </div>
      <div className="micro-note"><LockKeyhole size={14} /> Certains domaines se débloquent au fil de ta progression.</div>
    </div>
  );
}

function ChallengesScreen({ onNavigate }: { onNavigate: (screen: Screen) => void }) {
  const [tab, setTab] = useState("À faire");
  const tabs = ["À faire", "En cours", "Terminés"];
  return (
    <div className="screen">
      <div className="screen-header"><div><p className="eyebrow">APPRENDRE À DEUX</p><h1>Défis</h1></div><button className="icon-button"><Bell size={19} /></button></div>
      <div className="tabs" role="tablist">
        {tabs.map((item) => <button key={item} className={tab === item ? "is-active" : ""} onClick={() => setTab(item)} role="tab" aria-selected={tab === item}>{item}</button>)}
      </div>
      {tab === "À faire" ? <>
        <button className="challenge-card challenge-card--featured" onClick={() => onNavigate("challenge-detail")}>
          <div className="challenge-card__top"><span className="challenge-card__tag"><HeartHandshake size={14} /> DÉFI INTERGÉNÉRATIONNEL</span><span className="challenge-card__time">10 min</span></div>
          <h2>Le proverbe de ma famille</h2>
          <p>Demande à un proche de te raconter une expression qui traverse les générations.</p>
          <div className="challenge-card__bottom"><span><Sparkles size={14} /> +100 XP</span><span>Avec un proche</span><ArrowRight size={17} /></div>
        </button>
        <button className="challenge-card" onClick={() => toast("Ce défi se débloque au niveau 05.")}>
          <div className="challenge-card__top"><span className="challenge-card__tag challenge-card__tag--orange"><Music2 size={14} /> TRANSMISSION</span><LockKeyhole size={17} /></div>
          <h2>La chanson qui nous relie</h2>
          <p>Un air à fredonner ensemble, puis une histoire à transmettre.</p>
          <div className="challenge-card__bottom"><span><LockKeyhole size={14} /> Niveau 05 requis</span><ChevronRight size={17} /></div>
        </button>
      </> : <div className="empty-state"><span className="empty-state__icon">{tab === "En cours" ? "↗" : "✦"}</span><h2>{tab === "En cours" ? "Aucun défi en cours" : "Ton histoire commence ici"}</h2><p>{tab === "En cours" ? "Quand tu commenceras un défi, tu le retrouveras ici." : "Les défis terminés apparaîtront ici comme des souvenirs de transmission."}</p></div>}
    </div>
  );
}

function ProfileScreen({ onNavigate, badgeProgress }: { onNavigate: (screen: Screen) => void; badgeProgress: BadgeProgress }) {
  const badges = [
    { key: "regularity" as const, icon: "🌿", title: "Régularité" },
    { key: "perfectQuiz" as const, icon: "🏆", title: "Quiz parfait" },
    { key: "successGoal" as const, icon: "🎯", title: "Objectif de réussite" },
  ];
  return (
    <div className="screen">
      <div className="screen-header"><div><p className="eyebrow">TON ESPACE</p><h1>Profil</h1></div><button className="icon-button" onClick={() => onNavigate("account-settings")} aria-label="Ouvrir les réglages du compte"><Menu size={20} /></button></div>
      <section className="profile-hero"><div className="avatar avatar--large">A</div><div><h2>Awa Kouamé</h2><p>Abidjan · Jeune</p></div><button className="icon-button icon-button--small" onClick={() => onNavigate("account-settings")} aria-label="Gérer mon compte"><ArrowRight size={16} /></button></section>
      <div className="profile-stats"><StatPill icon={<Sparkles size={16} />} label="XP total" value="1 250" tone="purple" /><StatPill icon={<Flame size={16} fill="currentColor" />} label="Série" value="3 jours" tone="orange" /><StatPill icon={<Zap size={16} fill="currentColor" />} label="Énergie" value="4 / 5" tone="yellow" /></div>
      <section className="profile-section"><div className="section-heading"><div><p className="eyebrow">TA COLLECTION</p><h2>Badges</h2></div><button className="text-button">Voir tout <ChevronRight size={15} /></button></div><div className="badge-row">{badges.map(({ key, icon, title }) => <div className={`badge-item ${badgeProgress.unlocked[key] ? "badge-item--unlocked" : "badge-item--locked"}`} key={key}><span>{badgeProgress.unlocked[key] ? icon : "🔒"}</span><strong>{badgeProgress.unlocked[key] ? title : "À débloquer"}</strong></div>)}</div></section>
      <section className="profile-section"><div className="section-heading"><div><p className="eyebrow">TES DOMAINES</p><h2>Progression</h2></div></div>{categories.slice(0, 4).map(({ name, progress, tone }) => <div className="domain-row" key={name}><span>{name}</span><div><ProgressBar value={progress} className={`progress--${tone}`} /><strong>{progress}%</strong></div></div>)}</section>
    </div>
  );
}

function SeniorHomeScreen({ onNavigate }: { onNavigate: (screen: Screen) => void }) {
  const [done, setDone] = useState(false);
  return <div className="screen screen--senior-home">
    <div className="mobile-topline"><div><p className="eyebrow">MERCREDI 20 SEPTEMBRE</p><h1>Bonjour Mamie Awa <span className="wave">🌿</span></h1></div><button className="icon-button icon-button--light" onClick={() => toast("Votre espace est à jour.")}><Bell size={19} /></button></div>
    <p className="senior-welcome">Votre savoir mérite d'être transmis.</p>
    <section className={`daily-quest-card ${done ? "is-done" : ""}`}><div className="daily-quest-card__top"><span className="quest-leaf">🌿</span><span className="eyebrow eyebrow--purple">QUÊTE DU JOUR</span><span className="quest-status">{done ? "ACCOMPLIE" : "1 transmission"}</span></div><h2>{done ? "Merci pour cette transmission" : "Partagez un proverbe de votre enfance."}</h2><p>{done ? "Votre savoir est maintenant en attente de validation." : "Une phrase suffit pour faire vivre une mémoire."}</p>{done ? <button className="secondary-button secondary-button--full" onClick={() => onNavigate("senior-knowledge")}>Voir mes savoirs <ArrowRight size={15} /></button> : <button className="primary-button primary-button--full" onClick={() => { setDone(true); toast("Votre savoir a été envoyé pour validation."); }}>Ajouter mon savoir <ArrowRight size={15} /></button>}</section>
    <section className="senior-section"><div className="section-heading"><div><p className="eyebrow">MA TRANSMISSION</p><h2>En ce moment</h2></div><button className="text-button" onClick={() => onNavigate("senior-knowledge")}>Voir tout <ChevronRight size={15} /></button></div><div className="senior-status-grid"><button onClick={() => onNavigate("senior-knowledge")}><strong>2</strong><span>En attente</span><LockKeyhole size={14} /></button><button onClick={() => onNavigate("senior-knowledge")}><strong>12</strong><span>Savoirs transmis</span><Sparkles size={14} /></button></div></section>
    <section className="senior-section"><div className="section-heading"><div><p className="eyebrow">DÉFIS REÇUS</p><h2>Les jeunes demandent</h2></div><button className="text-button" onClick={() => onNavigate("senior-challenges")}>Voir tout <ChevronRight size={15} /></button></div><button className="received-challenge-card" onClick={() => onNavigate("senior-challenges")}><span className="avatar avatar--small">K</span><span><strong>Koffi te demande</strong><small>Quelle chanson chantait-on pendant les fêtes ?</small></span><ArrowRight size={16} /></button></section>
    <div className="impact-strip"><HeartHandshake size={17} /><span><strong>86 jeunes</strong> ont découvert vos savoirs</span><ChevronRight size={15} /></div>
  </div>;
}

function SeniorKnowledgeScreen({ onNavigate }: { onNavigate: (screen: Screen) => void }) {
  const [tab, setTab] = useState("Tous");
  const knowledge = [{ title: "Le vieux peut encore apprendre", category: "Proverbe", status: "Publié", tone: "published" }, { title: "La fête des ignames chez nous", category: "Tradition", status: "En attente", tone: "pending" }, { title: "Sauce graine de ma mère", category: "Recette", status: "Brouillon", tone: "draft" }];
  const visible = knowledge.filter((item) => tab === "Tous" || item.status === tab);
  return <div className="screen screen--senior-knowledge"><div className="screen-header"><div><p className="eyebrow">MA BIBLIOTHÈQUE</p><h1>Savoirs</h1></div><button className="icon-button" onClick={() => onNavigate("senior-profile")}><CircleUserRound size={19} /></button></div><button className="primary-button primary-button--full knowledge-add-button" onClick={() => toast("L'éditeur de savoir sera ouvert ici.")}><Plus size={17} /> Ajouter un savoir</button><div className="knowledge-tabs">{["Tous", "Brouillon", "En attente", "Publié"].map((item) => <button key={item} className={tab === item ? "is-active" : ""} onClick={() => setTab(item)}>{item}</button>)}</div><div className="knowledge-list">{visible.map((item) => <button className="knowledge-card" key={item.title} onClick={() => toast(`${item.title} · ${item.status}`)}><span className={`knowledge-card__icon knowledge-card__icon--${item.tone}`}>{item.tone === "published" ? "✦" : item.tone === "pending" ? "◌" : "◒"}</span><span><strong>{item.title}</strong><small>{item.category} · {item.status}</small></span><ChevronRight size={16} /></button>)}</div><div className="knowledge-empty-note"><Sparkles size={15} /><span>Chaque histoire ajoutée enrichit la mémoire de KoumanPlay.</span></div></div>;
}

function SeniorChallengesScreen() {
  return <div className="screen"><div className="screen-header"><div><p className="eyebrow">ÉCHANGER AVEC LES JEUNES</p><h1>Défis</h1></div><button className="icon-button"><Bell size={19} /></button></div><div className="received-list"><button className="received-large-card"><div className="received-large-card__top"><span className="challenge-card__tag"><HeartHandshake size={14} /> QUESTION REÇUE</span><span>Il y a 2 h</span></div><h2>Quelle chanson chantait-on pendant les fêtes quand tu étais jeune ?</h2><div className="received-large-card__from"><span className="avatar avatar--small">K</span><span>Koffi · 18 ans</span><ArrowRight size={16} /></div></button><button className="received-large-card received-large-card--muted"><div className="received-large-card__top"><span className="challenge-card__tag challenge-card__tag--orange"><Music2 size={14} /> DÉFI TERMINÉ</span><Check size={16} /></div><h2>Raconte-nous un souvenir de rentrée.</h2><div className="received-large-card__from"><span className="avatar avatar--small">Y</span><span>Yasmine · 21 ans</span><ArrowRight size={16} /></div></button></div></div>;
}

function SeniorProfileScreen({ onNavigate }: { onNavigate: (screen: Screen) => void }) {
  return <div className="screen"><div className="screen-header"><div><p className="eyebrow">MON ESPACE</p><h1>Profil</h1></div><button className="icon-button" onClick={() => onNavigate("account-settings")} aria-label="Ouvrir les réglages du compte"><Menu size={20} /></button></div><section className="profile-hero"><div className="avatar avatar--large avatar--senior-profile">A</div><div><h2>Mamie Awa</h2><p>Abidjan · Aînée</p></div><button className="icon-button icon-button--small" onClick={() => onNavigate("account-settings")} aria-label="Gérer mon compte"><ArrowRight size={16} /></button></section><div className="profile-stats"><StatPill icon={<Sparkles size={16} />} label="Savoirs transmis" value="12" tone="purple" /><StatPill icon={<Flame size={16} fill="currentColor" />} label="Série" value="5 jours" tone="orange" /><StatPill icon={<UsersRound size={16} />} label="Jeunes touchés" value="86" tone="green" /></div><section className="profile-section"><div className="section-heading"><div><p className="eyebrow">MES BADGES</p><h2>Transmission</h2></div></div><div className="badge-row"><div className="badge-item badge-item--unlocked"><span>🌿</span><strong>Mémoire vivante</strong></div><div className="badge-item badge-item--unlocked"><span>🤝</span><strong>Lien créé</strong></div><div className="badge-item badge-item--locked"><span>🔒</span><strong>Voix de la région</strong></div></div></section><div className="impact-strip"><HeartHandshake size={17} /><span><strong>Votre impact grandit</strong><br />Chaque contribution compte.</span></div></div>;
}

function AccountSettingsScreen({ onBack }: { onBack: () => void }) {
  return <div className="screen screen--account-settings"><div className="screen-header"><div><p className="eyebrow">RÉGLAGES DU PROFIL</p><h1>Compte & sauvegarde</h1></div><button className="icon-button" onClick={onBack} aria-label="Retour au profil"><ArrowLeft size={19} /></button></div><div className="account-intro"><span className="account-intro__icon"><LockKeyhole size={20} /></span><div><strong>Jouer sans compte, c'est possible.</strong><p>Ta progression est conservée sur cet appareil. Crée un compte uniquement si tu veux la retrouver ailleurs.</p></div></div><section className="account-section"><p className="eyebrow">OPTIONNEL</p><h2>Sauvegarder ma progression</h2><button className="account-action" onClick={() => toast("La création de compte sera ouverte ici.")}><span className="account-action__icon"><Plus size={18} /></span><span><strong>Créer un compte</strong><small>Retrouver tes XP et tes badges sur tous tes appareils</small></span><ChevronRight size={17} /></button><button className="account-action" onClick={() => toast("La connexion sera ouverte ici.")}><span className="account-action__icon account-action__icon--soft"><ArrowRight size={18} /></span><span><strong>Se connecter</strong><small>Tu as déjà un compte KoumanPlay ?</small></span><ChevronRight size={17} /></button></section><div className="account-local-note"><Sparkles size={16} /><span><strong>Ton expérience reste complète sans inscription.</strong><br />Tu peux continuer à jouer, apprendre et transmettre librement.</span></div></div>;
}

const quizQuestions = [
  { question: "Que signifie le proverbe « On ne balaie pas la cour avec une seule main » ?", answers: ["On a besoin des autres pour réussir.", "Il faut travailler très tôt.", "La cour doit rester propre.", "Il ne faut jamais se reposer."], correct: "On a besoin des autres pour réussir.", explanation: "La coopération rend les tâches plus faciles et plus solides.", xp: 20 },
  { question: "Que veut dire « Le tambour ne se joue pas avec une seule main » ?", answers: ["La musique doit être silencieuse.", "La réussite vient de l'union.", "Il faut acheter un instrument.", "Les mains doivent être rapides."], correct: "La réussite vient de l'union.", explanation: "Ce proverbe rappelle que certaines réussites sont collectives.", xp: 20 },
  { question: "Quelle idée se rapproche de « Celui qui demande son chemin ne se perd pas » ?", answers: ["Demander de l'aide est une force.", "Il ne faut jamais voyager.", "Les chemins sont toujours courts.", "On doit tout savoir seul."], correct: "Demander de l'aide est une force.", explanation: "Poser une question permet d'avancer avec plus de confiance.", xp: 20 },
];

function QuizScreen({ onBack, onFinish, gameProgress, cooldownRemaining, onAnswerResult }: { onBack: () => void; onFinish: (score: number, total: number) => void; gameProgress: GameProgress; cooldownRemaining: number; onAnswerResult: (correct: boolean, xp: number) => void }) {
  const [questionIndex, setQuestionIndex] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const current = quizQuestions[questionIndex];
  const correct = current.correct;
  return (
    <div className="screen screen--quiz">
      <div className="quiz-header"><button className="icon-button" onClick={onBack}><X size={19} /></button><span>Activité 6 / 8</span><span className="quiz-energy"><Zap size={14} fill="currentColor" /> {gameProgress.energy === 0 ? formatEnergyCooldown(cooldownRemaining) : `${gameProgress.energy}/5`}</span></div>
      <ProgressBar value={72} className="quiz-progress" />
      <div className="quiz-context"><span>PROVERBES · NIVEAU 03</span><span>+20 XP</span></div>
      <div className="quiz-question"><span className="question-number">0{questionIndex + 1}</span><h1>{current.question}</h1><p>Prends ton temps, puis choisis la réponse qui te semble la plus juste.</p></div>
      <div className="answer-list">{current.answers.map((answer, index) => <button key={answer} className={`answer-option ${selected === answer ? "is-selected" : ""} ${submitted && answer === correct ? "is-correct" : ""} ${submitted && selected === answer && answer !== correct ? "is-wrong" : ""}`} onClick={() => !submitted && setSelected(answer)}><span className="answer-letter">{String.fromCharCode(65 + index)}</span><span>{answer}</span>{submitted && answer === correct && <Check size={18} />}</button>)}</div>
      {submitted && <div className="feedback feedback--success"><div className="feedback__icon"><Check size={17} /></div><div><strong>{selected === correct ? "✅ Bonne réponse !" : "❌ Mauvaise réponse !"}</strong><p>{selected === correct ? `+${current.xp} XP` : "-1 Énergie"} · {current.explanation}</p></div></div>}
      {!submitted ? <button className="primary-button primary-button--full" disabled={!selected || gameProgress.energy === 0} onClick={() => { const isCorrect = selected === correct; setSubmitted(true); if (isCorrect) setScore((currentScore) => currentScore + 1); onAnswerResult(isCorrect, current.xp); }}>Valider ma réponse <ArrowRight size={17} /></button> : questionIndex < quizQuestions.length - 1 ? <button className="primary-button primary-button--full" onClick={() => { setQuestionIndex(questionIndex + 1); setSelected(null); setSubmitted(false); }}>Question suivante <ArrowRight size={17} /></button> : <button className="secondary-button secondary-button--full" onClick={() => onFinish(score, quizQuestions.length)}>Voir mon résultat <Trophy size={17} /></button>}
    </div>
  );
}

function ResultsScreen({ score, total, onReplay, onHome }: { score: number; total: number; onReplay: () => void; onHome: () => void }) {
  const percentage = Math.round((score / total) * 100);
  const badge = percentage === 100 ? { icon: "🏆", title: "Maître des proverbes", copy: "Tu as trouvé toutes les bonnes réponses." } : percentage >= 66 ? { icon: "🌿", title: "Passeur de sagesse", copy: "Une belle progression, continue ton exploration." } : { icon: "✦", title: "Curieuse des racines", copy: "Chaque réponse est une nouvelle histoire apprise." };
  return <div className="screen screen--results"><div className="results-top"><span className="eyebrow eyebrow--purple">NIVEAU 03 · PROVERBES</span><button className="icon-button" onClick={onHome}><X size={18} /></button></div><div className="results-hero"><div className="results-orbit results-orbit--one" /><div className="results-orbit results-orbit--two" /><span className="results-trophy">{badge.icon}</span><span className="results-label">TON SCORE</span><strong>{score}<small> / {total}</small></strong><p>{percentage === 100 ? "Parfait !" : percentage >= 66 ? "Bravo, tu es sur la bonne voie." : "Continue à apprendre à ton rythme."}</p></div><div className="results-xp"><span><Sparkles size={16} /> XP gagné</span><strong>+{score * 20 + 60} XP</strong></div><section className="unlocked-badge"><div className="unlocked-badge__icon">{badge.icon}</div><div><span className="eyebrow eyebrow--purple">BADGE DÉBLOQUÉ</span><h2>{badge.title}</h2><p>{badge.copy}</p></div><Check size={18} /></section><div className="results-breakdown"><div><span>Bonnes réponses</span><strong>{score} / {total}</strong></div><div><span>Précision</span><strong>{percentage}%</strong></div><div><span>Prochaine étape</span><strong>Niveau 04</strong></div></div><button className="primary-button primary-button--full" onClick={onReplay}>Rejouer l'activité <ArrowRight size={17} /></button><button className="text-button text-button--center" onClick={onHome}>Retour à l'accueil</button></div>;
}

function ChallengeDetail({ onBack, onComplete }: { onBack: () => void; onComplete: () => void }) {
  const [step, setStep] = useState(1);
  return (
    <div className="screen screen--challenge-detail">
      <div className="detail-top"><button className="icon-button" onClick={onBack}><ArrowLeft size={19} /></button><span>Défi à la une</span><button className="icon-button" onClick={() => toast("Défi enregistré dans tes favoris.")}><Plus size={19} /></button></div>
      <div className="challenge-hero-art" style={{ backgroundImage: "linear-gradient(90deg, rgba(255,222,209,.52) 0%, rgba(255,237,218,.18) 58%, rgba(239,232,255,.12) 100%), url('/onboarding1.webp')" }}><div className="mini-scene mini-scene--grandma"><span>●</span></div><div className="mini-scene mini-scene--young"><span>●</span></div><div className="mini-scene__table" /><div className="mini-scene__spark">✦</div></div>
      <span className="eyebrow eyebrow--purple">DÉFI INTERGÉNÉRATIONNEL</span><h1>Le proverbe de ma famille</h1><p className="detail-lead">Un moment simple pour se raconter, apprendre l'un de l'autre et garder une trace d'une histoire qui compte.</p>
      <div className="detail-meta"><span><Sparkles size={15} /> +100 XP</span><span><UsersRound size={15} /> Avec un proche</span><span>10 min</span></div>
      <div className="stepper">{["Choisir un proche", "Échanger", "Valider"].map((item, index) => <div className={`step ${step > index ? "is-done" : ""} ${step === index + 1 ? "is-current" : ""}`} key={item}><span>{step > index + 1 ? <Check size={13} /> : index + 1}</span><label>{item}</label></div>)}</div>
      <div className="safety-note"><HeartHandshake size={17} /><p><strong>Un défi encadré</strong><br />À réaliser avec une personne de ton entourage, jamais avec un inconnu.</p></div>
      <button className="primary-button primary-button--full" onClick={() => step < 3 ? setStep(step + 1) : onComplete()}>{step === 1 ? "Choisir un proche" : step === 2 ? "J'ai échangé, continuer" : "Valider le défi"}<ArrowRight size={17} /></button>
      {step > 1 && <button className="text-button text-button--center" onClick={() => setStep(step - 1)}><ArrowLeft size={14} /> Revenir à l'étape précédente</button>}
    </div>
  );
}

const onboardingSlides = {
  "onboarding-play": { index: 1, eyebrow: "JOUER", title: "Découvrir en jouant", copy: "Des activités courtes pour apprendre, rire et progresser à ton rythme.", button: "Continuer", image: "/onboarding1.webp" },
  "onboarding-learn": { index: 2, eyebrow: "APPRENDRE", title: "Nos histoires ont de la valeur", copy: "Proverbes, contes, musique et traditions : une culture vivante à explorer.", button: "Continuer", image: "/onboarding2.webp" },
  "onboarding-share": { index: 3, eyebrow: "PARTAGER", title: "Créer du lien, vraiment", copy: "Des défis simples à réaliser avec une personne de ton entourage.", button: "Commencer", image: "/onboarding3.webp" },
} as const;

function SplashScreen({ onStart }: { onStart: () => void }) {
  return <div className="access-screen access-screen--splash">
    <div className="splash-art" style={{ backgroundImage: "linear-gradient(180deg, rgba(91,46,255,.04), rgba(24,21,40,.64)), url('/splash.webp')" }} />
    <div className="splash-overlay" />
    <div className="splash-content"><BrandMark /><span className="splash-kicker">JOUER · APPRENDRE · PARTAGER</span><h1>Les histoires<br /><em>nous rapprochent.</em></h1><p>Un jeu culturel intergénérationnel pour apprendre et transmettre autrement.</p><button className="primary-button primary-button--full" onClick={onStart}>Commencer <ArrowRight size={17} /></button></div>
  </div>;
}

function OnboardingScreen({ kind, onNext, onSkip }: { kind: "onboarding-play" | "onboarding-learn" | "onboarding-share"; onNext: () => void; onSkip: () => void }) {
  const slide = onboardingSlides[kind];
  return <div className="access-screen access-screen--onboarding">
    <div className="onboarding-top"><BrandMark compact /><button className="text-button" onClick={onSkip}>Passer</button></div>
    <div className={`onboarding-art onboarding-art--${kind}`} style={{ backgroundImage: `linear-gradient(180deg, rgba(248,245,239,.03) 25%, rgba(248,245,239,.6) 100%), url('${slide.image}')` }}><span className="onboarding-sticker">{kind === "onboarding-play" ? "✦" : kind === "onboarding-learn" ? "◒" : "♡"}</span></div>
    <div className="onboarding-copy"><span className="eyebrow eyebrow--purple">0{slide.index} / 03 · {slide.eyebrow}</span><h1>{slide.title}</h1><p>{slide.copy}</p><div className="onboarding-dots">{[1, 2, 3].map((dot) => <span className={dot === slide.index ? "is-active" : ""} key={dot} />)}</div><button className="primary-button primary-button--full" onClick={onNext}>{slide.button} <ArrowRight size={17} /></button></div>
  </div>;
}

function ProfileChoiceScreen({ onNext, onBack }: { onNext: (role: "jeune" | "senior") => void; onBack: () => void }) {
  const [role, setRole] = useState<"jeune" | "senior" | null>(null);
  return <div className="access-screen access-screen--form"><div className="access-header"><button className="icon-button" onClick={onBack}><ArrowLeft size={18} /></button><span className="access-step">DERNIÈRE ÉTAPE</span></div><div className="access-copy"><span className="eyebrow eyebrow--purple">TON PROFIL</span><h1>Comment veux-tu jouer ?</h1><p>Choisis le profil qui te ressemble. Pas besoin de compte pour commencer : tu pourras l'ajouter plus tard dans ton profil.</p></div><div className="role-list"><button className={`role-card ${role === "jeune" ? "is-selected" : ""}`} onClick={() => setRole("jeune")}><span className="role-card__avatar role-card__avatar--young">✦</span><span><strong>Jeune</strong><small>J'apprends et je partage</small></span><span className="role-card__check">{role === "jeune" ? <Check size={14} /> : ""}</span></button><button className={`role-card ${role === "senior" ? "is-selected" : ""}`} onClick={() => setRole("senior")}><span className="role-card__avatar role-card__avatar--senior">◒</span><span><strong>Aîné</strong><small>Je transmets et je découvre</small></span><span className="role-card__check">{role === "senior" ? <Check size={14} /> : ""}</span></button></div><div className="access-bottom"><button className="primary-button primary-button--full" disabled={!role} onClick={() => role && onNext(role)}>Entrer dans mon espace <ArrowRight size={17} /></button><span className="access-note">La création de compte est facultative et disponible dans les réglages du profil.</span></div></div>;
}

function MobileNav({ active, onNavigate, senior = false }: { active: Screen; onNavigate: (screen: Screen) => void; senior?: boolean }) {
  const items: NavItem[] = senior ? [{ id: "senior-home", label: "Accueil", icon: HomeIcon }, { id: "senior-knowledge", label: "Savoirs", icon: BookOpen }, { id: "senior-challenges", label: "Défis", icon: HeartHandshake }, { id: "senior-profile", label: "Profil", icon: CircleUserRound }] : navItems;
  return <nav className="mobile-nav">{items.map(({ id, label, icon: Icon }) => <button key={id} className={active === id ? "is-active" : ""} onClick={() => onNavigate(id)}><Icon size={19} strokeWidth={active === id ? 2.4 : 1.9} /><span>{label}</span>{id.includes("challenges") && <i />}</button>)}</nav>;
}

function AppShell() {
  const [activeScreen, setActiveScreen] = useState<Screen>("splash");
  const [showNotes, setShowNotes] = useState(true);
  const [profileRole, setProfileRole] = useState<"jeune" | "senior">("jeune");
  const [quizResult, setQuizResult] = useState({ score: 0, total: quizQuestions.length });
  const [gameProgress, setGameProgress] = useState<GameProgress>(() => getGameProgress());
  const [badgeProgress, setBadgeProgress] = useState<BadgeProgress>(() => getBadgeProgress());
  const [cooldownNow, setCooldownNow] = useState(() => Date.now());
  const cooldownRemaining = gameProgress.energy === 0 && gameProgress.energyRecoveryAt ? Math.max(0, gameProgress.energyRecoveryAt - cooldownNow) : 0;

  useEffect(() => {
    if (gameProgress.energy !== 0 || !gameProgress.energyRecoveryAt) return;
    const interval = window.setInterval(() => setCooldownNow(Date.now()), 1000);
    return () => window.clearInterval(interval);
  }, [gameProgress.energy, gameProgress.energyRecoveryAt]);

  useEffect(() => {
    if (gameProgress.energy === 0 && gameProgress.energyRecoveryAt && cooldownRemaining === 0) {
      const restored = { ...gameProgress, energy: MAX_ENERGY, energyRecoveryAt: null };
      setGameProgress(restored);
      saveGameProgress(restored);
    }
  }, [cooldownRemaining, gameProgress]);

  const handleAnswerResult = (correct: boolean, xp: number) => {
    setGameProgress((currentProgress) => {
      if (correct) {
        const next = { ...currentProgress, xp: currentProgress.xp + xp };
        saveGameProgress(next);
        toast(`✅ Bonne réponse ! +${xp} XP`);
        return next;
      }
      const nextEnergy = Math.max(0, currentProgress.energy - 1);
      const next = { ...currentProgress, energy: nextEnergy, energyRecoveryAt: nextEnergy === 0 ? Date.now() + ENERGY_RECOVERY_MS : currentProgress.energyRecoveryAt };
      saveGameProgress(next);
      toast("❌ Mauvaise réponse ! -1 Énergie");
      return next;
    });

    if (correct) {
      setBadgeProgress((currentBadges) => {
        const nextStreak = currentBadges.currentStreak + 1;
        const nextTotalCorrect = currentBadges.totalCorrect + 1;
        const nextUnlocked = {
          ...currentBadges.unlocked,
          regularity: currentBadges.unlocked.regularity || nextStreak >= REGULARITY_STREAK_REQUIRED,
          successGoal: currentBadges.unlocked.successGoal || nextTotalCorrect >= SUCCESS_GOAL_UNLOCK_AT,
        };
        const next = { unlocked: nextUnlocked, currentStreak: nextStreak, bestStreak: Math.max(currentBadges.bestStreak, nextStreak), totalCorrect: nextTotalCorrect };
        if (!currentBadges.unlocked.regularity && nextUnlocked.regularity) toast("🏆 Nouveau badge débloqué ! Régularité");
        if (!currentBadges.unlocked.successGoal && nextUnlocked.successGoal) toast("🏆 Nouveau badge débloqué ! Objectif de réussite");
        saveBadgeProgress(next);
        return next;
      });
    } else {
      setBadgeProgress((currentBadges) => {
        const next = { ...currentBadges, currentStreak: 0 };
        saveBadgeProgress(next);
        return next;
      });
    }
  };

  const handleQuizFinish = (score: number, total: number) => {
    setQuizResult({ score, total });
    if (score === total) {
      setBadgeProgress((currentBadges) => {
        if (currentBadges.unlocked.perfectQuiz) return currentBadges;
        const next = { ...currentBadges, unlocked: { ...currentBadges.unlocked, perfectQuiz: true } };
        saveBadgeProgress(next);
        toast("🏆 Nouveau badge débloqué ! Quiz parfait");
        return next;
      });
    }
    navigate("results");
  };

  const screenTitle = useMemo(() => ({ splash: "Splash", "onboarding-play": "Onboarding", "onboarding-learn": "Onboarding", "onboarding-share": "Onboarding", "profile-choice": "Profil", home: "Accueil", play: "Jouer", knowledge: "Savoirs", "senior-home": "Accueil Aîné", "senior-knowledge": "Savoirs", "senior-challenges": "Défis", "senior-profile": "Profil", challenges: "Défis", profile: "Profil", "account-settings": "Compte", quiz: "Activité", results: "Résultats", "challenge-detail": "Défi" })[activeScreen], [activeScreen]);
  const navigate = (screen: Screen) => {
    if (screen === "quiz" && gameProgress.energy === 0) {
      toast(`Énergie épuisée · disponible dans ${formatEnergyCooldown(cooldownRemaining)}`);
      return;
    }
    setActiveScreen(screen);
  };

  return (
    <main className="site-shell">
      <header className="site-header">
        <BrandMark />
        <div className="site-header__center"><span className="live-dot" /> Prototype interactif <span className="site-header__slash">/</span> MVP mobile</div>
        <div className="site-header__actions"><button className="header-link" onClick={() => toast("La présentation du projet sera ajoutée après validation de la maquette.")}>À propos</button><button className="header-avatar" onClick={() => navigate("profile")}>A</button></div>
      </header>
      <section className="showcase">
        <div className="showcase__intro">
          <div className="showcase__kicker"><span>01</span><div /><span>Expérience utilisateur</span></div>
          <h1>Le jeu comme<br /><em>point de départ.</em></h1>
          <p className="showcase__lead">KoumanPlay transforme les savoirs culturels en moments de jeu, puis les moments de jeu en occasions de se retrouver.</p>
          <div className="showcase__facts"><div><strong>390 × 844</strong><span>format de référence</span></div><div><strong>4 onglets</strong><span>navigation claire</span></div><div><strong>+100 XP</strong><span>pour créer du lien</span></div></div>
          <div className="showcase__hint"><span className="hint-line" />Clique sur les écrans pour explorer la maquette</div>
        </div>
        <div className="showcase__device-wrap">
          <div className="device-shadow" />
          <div className="phone-frame">
            <div className="phone-speaker" />
            <div className="phone-screen">
              <div className="phone-status"><span>9:41</span><span>● ◔ ▰</span></div>
              <div className="phone-content">
                <div key={activeScreen} className={`screen-transition screen-transition--${activeScreen}`}>
                {activeScreen === "splash" && <SplashScreen onStart={() => navigate("onboarding-play")} />}
                {activeScreen === "onboarding-play" && <OnboardingScreen kind="onboarding-play" onNext={() => navigate("onboarding-learn")} onSkip={() => navigate("profile-choice")} />}
                {activeScreen === "onboarding-learn" && <OnboardingScreen kind="onboarding-learn" onNext={() => navigate("onboarding-share")} onSkip={() => navigate("profile-choice")} />}
                {activeScreen === "onboarding-share" && <OnboardingScreen kind="onboarding-share" onNext={() => navigate("profile-choice")} onSkip={() => navigate("profile-choice")} />}
                {activeScreen === "profile-choice" && <ProfileChoiceScreen onNext={(role) => { setProfileRole(role); navigate(role === "senior" ? "senior-home" : "home"); }} onBack={() => navigate("onboarding-share")} />}
                {activeScreen === "home" && <HomeScreen onNavigate={navigate} profileRole={profileRole} gameProgress={gameProgress} cooldownRemaining={cooldownRemaining} />}
                {activeScreen === "play" && <PlayScreen onNavigate={navigate} />}
                {activeScreen === "knowledge" && <PlayScreen onNavigate={navigate} />}
                {activeScreen === "senior-home" && <SeniorHomeScreen onNavigate={navigate} />}
                {activeScreen === "senior-knowledge" && <SeniorKnowledgeScreen onNavigate={navigate} />}
                {activeScreen === "senior-challenges" && <SeniorChallengesScreen />}
                {activeScreen === "senior-profile" && <SeniorProfileScreen onNavigate={navigate} />}
                {activeScreen === "challenges" && <ChallengesScreen onNavigate={navigate} />}
                {activeScreen === "profile" && <ProfileScreen onNavigate={navigate} badgeProgress={badgeProgress} />}
                {activeScreen === "account-settings" && <AccountSettingsScreen onBack={() => navigate(profileRole === "senior" ? "senior-profile" : "profile")} />}
                {activeScreen === "quiz" && <QuizScreen onBack={() => navigate("home")} gameProgress={gameProgress} cooldownRemaining={cooldownRemaining} onAnswerResult={handleAnswerResult} onFinish={handleQuizFinish} />}
                {activeScreen === "results" && <ResultsScreen score={quizResult.score} total={quizResult.total} onReplay={() => navigate("quiz")} onHome={() => navigate("home")} />}
                {activeScreen === "challenge-detail" && <ChallengeDetail onBack={() => navigate("home")} onComplete={() => { navigate("challenges"); toast("Défi validé · +100 XP"); }} />}
                </div>
              </div>
              {(activeScreen === "home" || activeScreen === "play" || activeScreen === "knowledge" || activeScreen === "challenges" || activeScreen === "profile") && <MobileNav active={activeScreen} onNavigate={navigate} />}
              {(activeScreen === "senior-home" || activeScreen === "senior-knowledge" || activeScreen === "senior-challenges" || activeScreen === "senior-profile") && <MobileNav active={activeScreen} onNavigate={navigate} senior />}
            </div>
          </div>
          <div className="device-label device-label--top"><span>Prototype</span><strong>{screenTitle}</strong></div>
          <div className="device-label device-label--bottom">Écran de référence<br /><strong>390 × 844 px</strong></div>
        </div>
        <aside className={`notes-panel ${showNotes ? "is-visible" : ""}`}>
          <button onClick={() => setShowNotes(false)} aria-label="Fermer les notes"><X size={16} /></button>
          <span className="eyebrow eyebrow--purple">NOTE DE DESIGN</span>
          <p>Une interface chaleureuse et adulte : le violet structure l'expérience, les accents terracotta évoquent la transmission.</p>
          <div className="notes-panel__rule" /><span className="notes-panel__caption">Design System V1 · Sept. 2026</span>
        </aside>
      </section>
      <footer className="site-footer"><span><BrandMark compact /></span><span>Maquette UX interactive · KoumanPlay</span><span className="site-footer__right">Jouer <span>→</span> Apprendre <span>→</span> Partager</span></footer>
    </main>
  );
}

export default function Home() {
  return <AppShell />;
}
